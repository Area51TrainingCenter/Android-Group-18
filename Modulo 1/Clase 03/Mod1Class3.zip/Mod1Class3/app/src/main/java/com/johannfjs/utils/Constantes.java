package com.johannfjs.utils;

import com.johannfjs.models.Direcciones;

import java.util.ArrayList;

/**
 * Created by johannfjs on 14/11/2015.
 */
public class Constantes {
    public static ArrayList<Direcciones> lista = new ArrayList<Direcciones>();
}
